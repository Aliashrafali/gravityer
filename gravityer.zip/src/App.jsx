import React from 'react'
import './App.css'
import Longest from './components/Longest'

function App() {
  return (
    <>
      <Longest />
    </>
  )
}

export default App
